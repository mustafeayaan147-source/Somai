SOMAI - Render setup

1. Upload this project to your Render Web Service.
2. Build Command: npm install
3. Start Command: npm start
4. Environment Variable:
   OPENROUTER_API_KEY = your OpenRouter key
5. Optional:
   OPENROUTER_MODEL = openai/gpt-4o-mini

Never put the API key inside index.html.
